import os
os.system("clear")

#input
print("<============== Data Diri Mahasiswa ==============>")
nim = input("Masukan Nim :")
nama = input("Nama Mahasiswa :")
jurusan = input("Jurusan Kamu :")
alamat = input("Alamat kamu :")

#output
print("<============== Hasil Cetak Data Diatas ==============>")
print("Nama : " +str(nama))
print("nim : " +str(nim))
print("Alamat lengkap : " +str(alamat))
print("jurusan saya : " +str(jurusan))
