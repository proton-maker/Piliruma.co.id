#latihan 1

print("=================================")
print("Nim = 19215148")
print("Nama = Dedek Syaputra Caniago")
print("Kelas = 19.1A.24")
print("Jurusan = Sistem Informasi")
print("=================================")
